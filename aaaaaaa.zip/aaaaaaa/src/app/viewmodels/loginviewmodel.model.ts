export class Loginviewmodel {
    Email:string;
    Password:string ;

}
