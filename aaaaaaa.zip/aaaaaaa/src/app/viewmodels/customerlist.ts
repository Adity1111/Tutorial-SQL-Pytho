export class customer {
    customerId:number;
    customerName:string;
    address:string;
     state:string;
    country:string;
    
}
