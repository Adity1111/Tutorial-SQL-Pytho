export class cart{  
    item:string;  
    itemprice:number;
    quantity:number;  
    totalprice:number;  
    
 }  
 