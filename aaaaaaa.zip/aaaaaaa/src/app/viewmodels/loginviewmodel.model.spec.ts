import { Loginviewmodel } from './loginviewmodel.model';

describe('Loginviewmodel', () => {
  it('should create an instance', () => {
    expect(new Loginviewmodel()).toBeTruthy();
  });
});
