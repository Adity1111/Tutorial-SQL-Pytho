import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productregistration',
  templateUrl: './productregistration.component.html',
  styleUrls: ['./productregistration.component.css']
})
export class ProductregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
