import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feeback',
  templateUrl: './feeback.component.html',
  styleUrls: ['./feeback.component.css']
})
export class FeebackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
